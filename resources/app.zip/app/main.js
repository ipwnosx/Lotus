﻿const electron = require('electron');
var scraper = require('google-search-scraper');

var fs = require('fs');
/*******************************/
/*        Declaring Vars       */
/*******************************/

const { app, BrowserWindow, session } = require('electron')
const remote = electron.remote;
/*******************************/
/*          Functions          */
/*******************************/

function quitApplication(){
    if (process.platform !== 'darwin') { remote.app.exit(); }
}
function minApplication(){
  remote.BrowserWindow.getFocusedWindow().minimize();
}

function createWindow () {
  // Create the browser window.
  let win = new BrowserWindow({ width: 700, height: 550, frame: false, show: false, backgroundColor: '#1C2D37',
  webPreferences: {
      nodeIntegration: true
    }
   });
  win.once('ready-to-show', () => {
	  win.show();
	});

  // and load the index.html of the app.
  win.loadFile('index.html');
  win.setMenu(null);
  win.setMinimumSize(700, 550)
  //win.webContents.openDevTools();
}

/*******************************/
/*            Script           */
/*******************************/

app.on('ready', createWindow);

